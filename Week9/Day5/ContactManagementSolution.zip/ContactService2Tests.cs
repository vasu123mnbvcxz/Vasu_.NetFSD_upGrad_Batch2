using NUnit.Framework;
using Moq;
using System.Collections.Generic;

[TestFixture]
public class ContactService2Tests
{
    private Mock<IContactRepository> _mockRepo;
    private ContactService2 _service;

    [SetUp]
    public void Setup()
    {
        _mockRepo = new Mock<IContactRepository>();
        _service = new ContactService2(_mockRepo.Object);
    }

    [Test]
    public void AddContact_ShouldCallRepository()
    {
        var contact = new Contact { Id = 1, Name = "Test", Email = "test@test.com" };
        _service.AddContact(contact);

        _mockRepo.Verify(r => r.Add(contact), Times.Once);
    }
}