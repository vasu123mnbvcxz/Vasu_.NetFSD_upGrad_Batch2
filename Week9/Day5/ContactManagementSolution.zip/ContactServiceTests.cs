using NUnit.Framework;
using System.Collections.Generic;

[TestFixture]
public class ContactServiceTests
{
    private ContactService _service;

    [SetUp]
    public void Setup()
    {
        _service = new ContactService();
    }

    [Test]
    public void AddContact_ShouldAddSuccessfully()
    {
        var contact = new Contact { Id = 1, Name = "Vasu", Email = "vasu@test.com" };
        _service.AddContact(contact);
        var result = _service.GetAllContacts();

        Assert.IsNotNull(result);
        Assert.AreEqual(1, result.Count);
    }
}