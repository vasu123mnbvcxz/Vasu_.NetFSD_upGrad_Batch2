using System.Collections.Generic;

public interface IContactRepository
{
    void Add(Contact contact);
    List<Contact> GetAll();
    bool Delete(int id);
}