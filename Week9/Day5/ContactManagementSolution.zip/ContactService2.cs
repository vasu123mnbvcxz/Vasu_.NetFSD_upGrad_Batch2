using System;
using System.Collections.Generic;

public class ContactService2
{
    private readonly IContactRepository _repo;

    public ContactService2(IContactRepository repo)
    {
        _repo = repo;
    }

    public void AddContact(Contact contact)
    {
        if (contact == null)
            throw new ArgumentNullException(nameof(contact));

        _repo.Add(contact);
    }

    public List<Contact> GetContacts()
    {
        return _repo.GetAll();
    }

    public bool RemoveContact(int id)
    {
        return _repo.Delete(id);
    }
}